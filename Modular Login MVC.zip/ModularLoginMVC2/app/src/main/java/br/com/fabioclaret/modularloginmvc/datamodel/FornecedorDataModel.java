package br.com.fabioclaret.modularloginmvc.datamodel;

public class FornecedorDataModel {
}
