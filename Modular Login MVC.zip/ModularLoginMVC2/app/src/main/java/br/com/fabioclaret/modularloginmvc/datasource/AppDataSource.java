package br.com.fabioclaret.modularloginmvc.datasource;

public class AppDataSource {
}
