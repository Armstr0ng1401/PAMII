package br.com.fabioclaret.modularloginmvc.controller;

public class UsuarioController {
}
